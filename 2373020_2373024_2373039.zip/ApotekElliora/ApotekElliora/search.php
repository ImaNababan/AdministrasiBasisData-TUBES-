<?php
include 'koneksi.php';

// Ambil query pencarian dari URL
$query = isset($_GET['query']) ? $_GET['query'] : '';

// Query untuk mengambil data dari tabel stok dengan kondisi pencarian
$sql = "SELECT id_obat, nama_obat, golongan, total, tipe, harga FROM obat";
if ($query) {
    $sql .= " WHERE nama_obat LIKE '%" . $koneksi->real_escape_string($query) . "%' 
    OR golongan LIKE '%" . $koneksi->real_escape_string($query) . "%' 
    OR tipe LIKE '%" . $koneksi->real_escape_string($query) . "%' 
    OR total LIKE '%" . $koneksi->real_escape_string($query) . "%' 
    OR harga LIKE '%" . $koneksi->real_escape_string($query) . "%'";
}
$result = $koneksi->query($sql);

// Tampilkan hasil pencarian
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<th scope='row'>" . $row['id_obat'] . "</th>";
        echo "<td>" . $row['nama_obat'] . "</td>";
        echo "<td>" . $row['golongan'] . "</td>";
        echo "<td>" . $row['total'] . "</td>";
        echo "<td>" . $row['tipe'] . "</td>";
        echo "<td> Rp " . number_format($row['harga'], 2, ',', '.') . "</td>"; // Format harga
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>Tidak ada data</td></tr>";
}

$koneksi->close();
?>