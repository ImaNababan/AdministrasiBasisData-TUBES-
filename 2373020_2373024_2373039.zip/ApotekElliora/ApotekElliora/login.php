<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'apotekelliora';

// Koneksi ke database
$koneksi = new mysqli($host, $user, $password, $database);

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Ambil input dari form
$username = trim($_POST['username']);
$password_input = trim($_POST['password']);

// Query untuk mencari username dan password
$sql = "SELECT password FROM petugas WHERE username = ?";
$cek = $koneksi->prepare($sql);
$cek->bind_param("s", $username);
$cek->execute();
$hasil = $cek->get_result();

if ($hasil->num_rows > 0) {
    // Ambil password dari database
    $row = $hasil->fetch_assoc();
    $db_password = $row['password'];

    // Verifikasi password dengan membandingkan langsung
    if ($password_input === $db_password) {
        echo "<script>alert('Login berhasil!'); window.location.href='dashboard.php';</script>";
    } else {
        echo "<script>alert('Password salah!'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Username tidak ditemukan!'); window.history.back();</script>";
}

$cek->close();
$koneksi->close();
?>