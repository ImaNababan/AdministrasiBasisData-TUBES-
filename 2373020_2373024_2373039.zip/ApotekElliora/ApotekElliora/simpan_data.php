<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'apotekelliora';

// Koneksi ke database
$koneksi = new mysqli($host, $user, $password, $database);

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Aktifkan laporan kesalahan untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi data untuk registrasi pengguna
    if (isset($_POST['username'], $_POST['password'], $_POST['telepon'], $_POST['level'])) {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        $telepon = trim($_POST['telepon']);
        $level = $_POST['level'];

        if (empty($username) || empty($password) || empty($telepon)) {
            echo "<script>alert('Semua field harus diisi.'); window.history.back();</script>";
            exit;
        }

        // Cek apakah username sudah terpakai
        $sql = "SELECT * FROM petugas WHERE username = ?";
        $cek = $koneksi->prepare($sql);
        $cek->bind_param("s", $username);
        $cek->execute();
        $hasil = $cek->get_result();

        if ($hasil->num_rows > 0) {
            echo "<script>alert('Username sudah terpakai. Silakan pilih username lain.'); window.history.back();</script>";
        } else {
            // Simpan data pengguna baru
            $stmt = $koneksi->prepare("INSERT INTO petugas (username, password, telepon, level) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $username, $password, $telepon, $level);

            if ($stmt->execute()) {
                // Ambil ID pengguna yang baru aja dimasukkan
                $user_id = $koneksi->insert_id;

                // Tampilkan pesan sukses dengan ID pengguna
                echo "<script>alert('Registrasi berhasil! KODE PENGGUNA ANDA ADALAH $user_id. Silakan login.'); window.location.href='pages-login.php';</script>";
            } else {
                echo "<script>alert('Registrasi gagal: " . $stmt->error . "'); window.history.back();</script>";
            }

            $stmt->close();
        }

        $cek->close();
    }

    // Validasi data untuk transaksi supplier dan obat
    if (isset($_POST['nama_supplier'], $_POST['alamat'], $_POST['nomor_telepon'], $_POST['email'],
              $_POST['nama_obat'], $_POST['golongan'], $_POST['tipe'], $_POST['jumlah'], $_POST['harga'])) {
                $nama_supplier = trim($_POST['nama_supplier']);
                $alamat = trim($_POST['alamat']);
                $nomor_telepon = trim($_POST['nomor_telepon']);
                $email = trim($_POST['email']);
                $nama_obat = trim($_POST['nama_obat']);
                $golongan = trim($_POST['golongan']);
                $tipe = trim($_POST['tipe']);
                $jumlah = trim($_POST['jumlah']);
                $harga = trim($_POST['harga']);
        if (empty($nama_supplier) || empty($alamat) || empty($nomor_telepon) || empty($email) ||
            empty($nama_obat) || empty($golongan) || empty($tipe) || empty($jumlah) || empty($harga)) {
            echo "<script>alert('Semua field harus diisi.'); window.history.back();</script>";
            exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "<script>alert('Format email tidak valid.'); window.history.back();</script>";
            exit;
        }

        if (!is_numeric($nomor_telepon) || !is_numeric($jumlah) || !is_numeric($harga)) {
            echo "<script>alert('Nomor telepon, jumlah, dan harga harus berupa angka.'); window.history.back();</script>";
            exit;
        }

        try {
            // Mulai transaksi
            $koneksi->begin_transaction();
        
            // Simpan data obat
            $stmt_obat = $koneksi->prepare("INSERT INTO obat (nama_obat, golongan, tipe, total, harga) VALUES (?, ?, ?, ?, ?)");
            $stmt_obat->bind_param("sssdi", $nama_obat, $golongan, $tipe, $jumlah, $harga);
        
            if (!$stmt_obat->execute()) {
                throw new Exception("Gagal menyimpan data obat: " . $stmt_obat->error);
            }
            $id_obat = $stmt_obat->insert_id;
        
            $stmt_supplier = $koneksi->prepare("INSERT INTO supplier (nama_supplier, alamat, nomor_telepon, email, id_obat) VALUES (?, ?, ?, ?, ?)");
            $stmt_supplier->bind_param("ssssi", $nama_supplier, $alamat, $nomor_telepon, $email, $id_obat);
            
            if (!$stmt_supplier->execute()) {
                throw new Exception("Gagal menyimpan data supplier: " . $stmt_supplier->error);
            }
            
            // Memastikan ID terakhir yang dihasilkan oleh AUTO_INCREMENT diambil dari koneksi
            $id_supplier = $koneksi->insert_id;

        
            // Commit jika semua berhasil
            $koneksi->commit();
            echo "<script>alert('Data berhasil disimpan!'); window.location.href = 'pages-supplier.php';</script>";
        
        } catch (Exception $e) {
            $koneksi->rollback();
            echo "<script>alert('Terjadi kesalahan: " . htmlspecialchars($e->getMessage()) . "'); window.history.back();</script>";
        } finally {
            // Tutup semua statement
            if (isset($stmt_obat)) $stmt_obat->close();
            if (isset($stmt_supplier)) $stmt_supplier->close();
            if (isset($stmt_transaksi)) $stmt_transaksi->close();

            $koneksi->close();
        }
    }
}
?>
