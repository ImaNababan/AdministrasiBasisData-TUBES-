Copy code
<?php
include 'koneksi.php';

// Cek jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $id_user = $_POST['id_user'];
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $telepon_pelanggan = $_POST['telepon_pelanggan'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $total_harga = $_POST['total_harga'];
    $id_obat = $_POST['id_obat'];
    $jumlah_pembelian = $_POST['jumlah_pembelian'];
    $harga_satuan = isset($_POST['hargaSatuan']) ? $_POST['hargaSatuan'] : null;
    // Cek apakah harga_satuan valid
    if ($harga_satuan === null) {
        echo "<div class='alert alert-danger'>Harga satuan tidak ditemukan.</div>";
        exit();
    }

    // Mulai transaksi
    $koneksi->begin_transaction();

    try {
        // 1. Simpan data pelanggan
$stmt = $koneksi->prepare("INSERT INTO pelanggan (nama, telepon) VALUES (?, ?)");
$stmt->bind_param("ss", $nama_pelanggan, $telepon_pelanggan); // Hanya dua parameter
if (!$stmt->execute()) {
    throw new Exception("Error saat menyimpan pelanggan: " . $stmt->error);
}
$id_pelanggan = $stmt->insert_id; // Ambil ID pelanggan yang baru aja disimpan
$stmt->close();
        // 2. Cek apakah id_obat ada di tabel obat dan ambil stok
$stmt = $koneksi->prepare("SELECT total FROM obat WHERE id_obat = ?");
$stmt->bind_param("i", $id_obat);
$stmt->execute();
$stmt->bind_result($total);
$stmt->fetch();
$stmt->close();

// untuk cek stok mencukupi atau tidak
if ($total < $jumlah_pembelian) {
    echo "<script>
            alert('Obat habis atau stok tidak mencukupi.');
            window.location.href = 'transaksi.php'; // Ganti dengan URL halaman yang diinginkan
          </script>";
    exit();
}
        // 3. Simpan data transaksi ke dalam tabel transaksi
        $stmt = $koneksi->prepare("INSERT INTO transaksi (id_user, id_obat, jumlah, harga, total_harga, tanggal_transaksi, id_pelanggan, pembayaran) VALUES (?, ?, ?, ?, ?, CURDATE(), ?, ?)");
        $stmt->bind_param("iiidiis", $id_user, $id_obat, $jumlah_pembelian, $harga_satuan, $total_harga, $id_pelanggan, $metode_pembayaran);
        if (!$stmt->execute()) {
            throw new Exception("Error saat menyimpan transaksi: " . $stmt->error);
        }
        $id_transaksi = $stmt->insert_id; // Ambil ID transaksi yang baru saja disimpan
        $stmt->close();

        //update stok setiap kali beli
        $koneksi->commit();
        $stmt = $koneksi->prepare("UPDATE obat SET total = total - ? WHERE id_obat = ?");
        $stmt->bind_param("ii", $jumlah_pembelian, $id_obat);
        if (!$stmt->execute()) {
            throw new Exception("Error saat mengurangi stok obat: " . $stmt->error);
        }
        $stmt->close();
        echo "<script>
                alert('Transaksi berhasil disimpan!');
                window.location.href = 'transaksi.php'; // Ganti dengan URL halaman yang diinginkan
              </script>";
        } catch (Exception $e) {
        // Rollback jika ada kesalahan
        $koneksi->rollback();
        echo "<div class='alert alert-danger'>Transaksi gagal: " . $e->getMessage() . "</div>";
    }
}

// Ambil data transaksi untuk ditampilkan
$query = "SELECT t.id_transaksi, t.tanggal_transaksi, p.nama, t.total_harga 
          FROM transaksi t 
          JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan 
          ORDER BY t.tanggal_transaksi DESC";
$result = $koneksi->query($query);
// Cek jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama_supplier = $_POST['nama_supplier'];
    $alamat = $_POST['alamat'];
    $nomor_telepon = $_POST['nomor_telepon'];
    $email = $_POST['email'];
    $id_obat = $_POST['id_obat'];
    $jumlah_pembelian = $_POST['jumlah_pembelian'];
    $harga_satuan = $_POST['harga_satuan'];

    // Mulai transaksi
    $koneksi->begin_transaction();

    try {
        // 1. Simpan data supplier
        $stmt = $koneksi->prepare("INSERT INTO supplier (nama, alamat, telepon, email) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nama_supplier, $alamat, $nomor_telepon, $email);
        $stmt->execute();
        $id_supplier = $stmt->insert_id; // Ambil ID supplier yang baru saja disimpan
        $stmt->close();

        // 2. Simpan data obat dan transaksi
        $stmt = $koneksi->prepare("INSERT INTO transaksi (id_supplier, id_obat, jumlah, harga, total_harga, tanggal_transaksi) VALUES (?, ?, ?, ?, ?, CURDATE())");
        $total_harga = $jumlah_pembelian * $harga_satuan; // Hitung total harga
        $stmt->bind_param("iiidi", $id_supplier, $id_obat, $jumlah_pembelian, $harga_satuan, $total_harga);
        $stmt->execute();
        $stmt->close();

        $koneksi->commit();
        echo "<div class='alert alert-success'>Transaksi berhasil disimpan!</div>";
    } catch (Exception $e) {
        // Rollback jika ada kesalahan
        $koneksi->rollback();
        echo "<div class='alert alert-danger'>Transaksi gagal: " . $e->getMessage() . "</div>";
    }
}
?>
