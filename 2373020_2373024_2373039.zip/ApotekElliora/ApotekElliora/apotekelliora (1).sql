-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2025 at 01:16 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apotekelliora`
--

-- --------------------------------------------------------

--
-- Table structure for table `obat`
--

CREATE TABLE `obat` (
  `id_obat` int(11) NOT NULL,
  `nama_obat` varchar(255) NOT NULL,
  `golongan` varchar(255) NOT NULL,
  `total` int(11) NOT NULL,
  `tipe` enum('kapsul','sirup','tablet','') NOT NULL,
  `harga` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `obat`
--

INSERT INTO `obat` (`id_obat`, `nama_obat`, `golongan`, `total`, `tipe`, `harga`) VALUES
(1, 'Paracetamol', 'Analgesik', 100, 'tablet', 5000.00),
(2, 'Amoxicillin', 'Antibiotik', 50, 'kapsul', 10000.00),
(3, 'Vitamin C 500mg', 'Suplemen', 200, 'tablet', 8000.00),
(4, 'Ibuprofen', 'Analgesik', 80, 'tablet', 7000.00),
(5, 'Salbutamol', 'Bronkodilator', 22, 'sirup', 15000.00),
(6, 'Cetirizine', 'Antihistamin', 120, 'tablet', 6000.00),
(7, 'Albendazole', 'Antiparasit', 70, 'kapsul', 9000.00),
(8, 'Loratadine', 'Antihistamin', 59, 'tablet', 7000.00),
(9, 'Dextromethorphan', 'Antitusif', 90, 'sirup', 12000.00),
(10, 'Metformin', 'Antidiabetik', 99, 'tablet', 8500.00),
(11, 'Ranitidine', 'Antasid', 40, 'kapsul', 9500.00),
(12, 'Amlodipine', 'Antihipertensi', 75, 'tablet', 8000.00),
(13, 'Cefadroxil', 'Antibiotik', 52, 'kapsul', 11000.00),
(14, 'Prednisolone', 'Kortikosteroid', 45, 'tablet', 6500.00),
(15, 'Hydroxychloroquine', 'Antimalaria', 227, 'tablet', 20000.00),
(16, 'Omeprazole', 'Antasid', 85, 'kapsul', 12500.00),
(17, 'Simvastatin', 'Hipolipidemik', 119, 'tablet', 7000.00),
(18, 'Clopidogrel', 'Antiplatelet', 50, 'tablet', 17000.00),
(19, 'Furosemide', 'Diuretik', 65, 'tablet', 7500.00),
(20, 'Azithromycin', 'Antibiotik', 35, 'kapsul', 18000.00),
(21, 'Dexamethasone', 'Kortikosteroid', 40, 'tablet', 8500.00),
(22, 'Erythromycin', 'Antibiotik', 45, 'kapsul', 12500.00),
(23, 'Acyclovir', 'Antiviral', 70, 'tablet', 9500.00),
(24, 'Mefenamic Acid', 'Analgesik', 90, 'tablet', 8000.00),
(25, 'Ketoprofen', 'Analgesik', 60, 'tablet', 8500.00),
(26, 'Bisoprolol', 'Antihipertensi', 50, 'tablet', 9000.00),
(27, 'Ciprofloxacin', 'Antibiotik', 40, 'kapsul', 15000.00),
(28, 'Domperidone', 'Antiemetik', 98, 'tablet', 7000.00),
(29, 'Lansoprazole', 'Antasid', 50, 'kapsul', 12000.00),
(30, 'Phenylephrine', 'Dekongestan', 93, 'sirup', 13000.00),
(42, 'Panadol Extra', 'Bebas', 100, 'tablet', 28000.00),
(46, 'Sanmagh', 'Antasida', 100, 'sirup', 78000.00),
(47, 'Asam Mefenamat', 'Antibiotik', 100, 'tablet', 5000.00),
(48, 'wegf', 'JHWEVF', 32, 'sirup', 1232.00),
(49, 'Asam Mefenamat', 'Antibiotik', 98, 'tablet', 5000.00),
(50, 'Ketoconazole', 'Antibiotik', 100, 'kapsul', 17000.00),
(51, 'FG Troches Meiji', 'Antibiotik', 100, 'tablet', 25000.00);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `telepon` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama`, `telepon`) VALUES
(8, 'ewtewt', '2'),
(9, 'Surana', '2'),
(10, 'Yana`', '62434237463289'),
(17, 'Lola', '0832490'),
(19, 'Yana', '043586'),
(20, 'Yana', '043586'),
(21, 'Lamima', '08324112'),
(23, 'rena', '03495834'),
(24, 'Sieren', '087923465245'),
(25, 'Sieren', '087923465245'),
(26, 'Sieren', '087923465245'),
(27, 'Surya', '0895422659221'),
(29, 'Ima', '035834957394'),
(30, 'Jenifer', '01112'),
(31, 'Ima', '0895422659221'),
(32, 'dfgn', '12312432'),
(33, 'Lara', '089363442627'),
(34, '2', '34');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `telepon` varchar(50) NOT NULL,
  `level` enum('admin','hr','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id_user`, `username`, `password`, `telepon`, `level`) VALUES
(1, 'ima', '$2y$10$74f9ANK9AcF0m6zTvul7Dew8eK6/o3Da90ymOr5Ez.i', '90', ''),
(2, 'Subagja', '$2y$10$vBdtel4S/hOLI8b3cAWKUuZGLpQaOMYxvc0qz4M1gOH', '08', ''),
(3, 'XAS', '$2y$10$GIn5Mx97tilBCdyoKdJWRuxJIkNX3NhVoBidW1RwZxB', 'cds', ''),
(4, 'kira', '$2y$10$nm2aNoSJXXaubivgOeHZIuCmoullo4Pw.Odto44ezVI', 'kira', ''),
(5, 'sesa', '$2y$10$YBULkbvNIHuHNiMgCKGEV.DRwqGXS40oLIPUBx.myp2', '909090', ''),
(6, 'warna', '$2y$10$UFNfvcfP3eYHO10lnYgWGeRctqusM/p3tCwJwJr1MQC', '90u', ''),
(7, 'ima', 'ima', 'imamama', ''),
(8, 'kuli', 'kuli', '45345', ''),
(9, 'sania', '$2y$10$1ww75lr82HiI1Mv9jsH8auxPlrQMDdvqeFOGdHKgUai', '089', ''),
(10, 'lala', '$2y$10$Arh5ssK.ORCPd4gxVPlDt.cG9DmMmApqeKIDIxkb72u', 'lala', ''),
(11, 'Surana Subagja', '$2y$10$O71BuRBZ2nlbVrq4whWzUeWA1Lu4XzVZ8g7skimEZtt', '083543275', ''),
(12, 'Maria', '$2y$10$7A0UYf75hzSz0idMygbpB.7tslLaPonvUdzRoMtOBBW', '039248923', ''),
(13, 'Surya', 'Suryasumatri', '08437592345', 'admin'),
(14, 'Suryana', 'suryana222', '0895422659221', 'hr'),
(15, 'Jenifer', '12345678', '0893465734', 'admin'),
(16, 'Yulia', 'yuliatheresia', '085436289123', 'hr'),
(17, 'Ratna', 'ornamen123', '0895422659221', 'admin'),
(18, 'Lola', 'lola123456', '08976354747', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `Id_supplier` int(11) NOT NULL,
  `nama_supplier` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `nomor_telepon` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `id_obat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`Id_supplier`, `nama_supplier`, `alamat`, `nomor_telepon`, `email`, `id_obat`) VALUES
(17, 'Sanbe', 'Jl. Pajajaran no.3', '3242353', 'kosambiapotek@gmail.com', 46),
(20, 'Kimia Farma', 'Jl. Aceh Utara no. 30', '02274846321', 'kimiafarmakurdi@gmail.com', 49),
(21, 'Apotek K24', 'Jl. Budi Indah 10 no.123', '08974653891', 'apotekk24@gmail.com', 50),
(22, 'Bina San Prima', 'Jl. Kemayoran Timur Raya III No.21', '0223645171', 'bsp.kemayoran21@gmail.com', 51);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_obat` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL,
  `tanggal_transaksi` date NOT NULL,
  `id_pelanggan` int(255) NOT NULL,
  `pembayaran` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_user`, `id_obat`, `jumlah`, `harga`, `total_harga`, `tanggal_transaksi`, `id_pelanggan`, `pembayaran`) VALUES
(5, 2, 15, 2, 20000, 40000, '2025-01-04', 8, '0'),
(6, 3, 15, 3, 20000, 60000, '2025-01-04', 9, '0'),
(7, 2, 12, 8, 8000, 64000, '2025-01-04', 10, '0'),
(8, 3, 13, 3, 11000, 37500, '2025-01-04', 17, '0'),
(9, 3, 5, 8, 15000, 120000, '2025-01-04', 19, '0'),
(10, 8, 30, 2, 13000, 25000, '2025-01-04', 20, '0'),
(11, 9, 17, 1, 7000, 7000, '2025-01-04', 21, '0'),
(12, 2, 28, 2, 7000, 14000, '2025-01-04', 23, 'Tunai'),
(13, 8, 15, 2, 20000, 40000, '2025-01-05', 24, 'Transfer'),
(14, 10, 30, 3, 13000, 39000, '2025-01-05', 25, 'Transfer'),
(15, 5, 30, 2, 13000, 26000, '2025-01-05', 26, 'Cash'),
(16, 2, 10, 1, 8500, 8500, '2025-01-05', 27, 'Cash'),
(17, 15, 15, 1, 20000, 20000, '2025-01-05', 29, 'Cash'),
(18, 17, 12, 2, 8000, 16000, '2025-01-07', 30, 'Cash'),
(19, 18, 49, 2, 5000, 10000, '2025-01-07', 31, 'Transfer'),
(20, 3, 50, 1, 17000, 17000, '2025-01-07', 32, 'Cash'),
(21, 3, 30, 2, 13000, 26000, '2025-01-15', 33, 'Transfer'),
(22, 3, 8, 1, 7000, 7000, '2025-01-15', 34, 'Transfer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`Id_supplier`),
  ADD KEY `id_obat` (`id_obat`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_obat` (`id_obat`),
  ADD KEY `id_pelanggan` (`id_pelanggan`),
  ADD KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `obat`
--
ALTER TABLE `obat`
  MODIFY `id_obat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `Id_supplier` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `supplier`
--
ALTER TABLE `supplier`
  ADD CONSTRAINT `supplier_ibfk_1` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`),
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`),
  ADD CONSTRAINT `transaksi_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `petugas` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
