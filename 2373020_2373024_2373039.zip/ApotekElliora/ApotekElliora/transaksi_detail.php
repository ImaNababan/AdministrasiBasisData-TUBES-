
<?php
include 'koneksi.php';

// Cek jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $id_user = $_POST['id_user'];
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $telepon_pelanggan = $_POST['telepon_pelanggan'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $total_harga = $_POST['total_harga'];
    $id_obat = $_POST['id_obat'];
    $jumlah_pembelian = $_POST['jumlah_pembelian'];
    $harga_satuan = $_POST['hargaSatuan'];

    // Mulai transaksi
    $koneksi->begin_transaction();

    try {
        // 1. Simpan data pelanggan
        $stmt = $koneksi->prepare("INSERT INTO pelanggan (nama, telepon, pembayaran) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nama_pelanggan, $telepon_pelanggan, $metode_pembayaran);
        $stmt->execute();
        $id_pelanggan = $stmt->insert_id;
        $stmt->close();

        // 2. Simpan data transaksi
        $stmt = $koneksi->prepare("INSERT INTO transaksi (id_user, tanggal_transaksi, total_harga, id_pelanggan) VALUES (?, CURDATE(), ?, ?)");
        $stmt->bind_param("idi", $id_user, $total_harga, $id_pelanggan);
        $stmt->execute();
        $id_transaksi = $stmt->insert_id;
        $stmt->close();

        // 3. Simpan detail transaksi
        $stmt = $koneksi->prepare("INSERT INTO detail_transaksi (id_transaksi, id_obat, jumlah, harga) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiid", $id_transaksi, $id_obat, $jumlah_pembelian, $harga_satuan);
        $stmt->execute();
        $stmt->close();

        // Commit transaksi
        $koneksi->commit();
        echo "<div class='alert alert-success'>Transaksi berhasil disimpan!</div>";
    } catch (Exception $e) {
        // Rollback jika ada kesalahan
        $koneksi->rollback();
        echo "<div class='alert alert-danger'>Transaksi gagal: " . $e->getMessage() . "</div>";
    }
}

// Ambil data transaksi untuk ditampilkan
$query = "SELECT t.id_transaksi, t.tanggal_transaksi, p.nama, t.total_harga 
          FROM transaksi t 
          JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan 
          ORDER BY t.tanggal_transaksi DESC";
$result = $koneksi->query($query);
?>

 
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Forms / Validation - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Updated: Apr 20 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="dashboard.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo1.png" alt="">
        <span class="d-none d-lg-block">Apotek Elliora</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">4</span>
          </a><!-- End Notification Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
            <li class="dropdown-header">
              You have 4 new notifications
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-exclamation-circle text-warning"></i>
              <div>
                <h4>Lorem Ipsum</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>30 min. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-x-circle text-danger"></i>
              <div>
                <h4>Atque rerum nesciunt</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>1 hr. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-check-circle text-success"></i>
              <div>
                <h4>Sit rerum fuga</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>2 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-info-circle text-primary"></i>
              <div>
                <h4>Dicta reprehenderit</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>4 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>
            <li class="dropdown-footer">
              <a href="#">Show all notifications</a>
            </li>

          </ul><!-- End Notification Dropdown Items -->

        </li><!-- End Notification Nav -->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success badge-number">3</span>
          </a><!-- End Messages Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
            <li class="dropdown-header">
              You have 3 new messages
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-1.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Maria Hudson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>4 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-2.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Anna Nelson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>6 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-3.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>David Muldon</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>8 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="dropdown-footer">
              <a href="#">Show all messages</a>
            </li>

          </ul><!-- End Messages Dropdown Items -->

        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2">K. Anderson</span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6>Kevin Anderson</h6>
              <span>Web Designer</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.php">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.php">
                <i class="bi bi-gear"></i>
                <span>Account Settings</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-faq.php">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link collapsed" href="dashboard.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="transaksi.php">
          <i class="bi bi-handbag-fill"></i><span>Transaksi</span><i></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          
        </ul>
      </li><!-- End Transaksi -->


      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-layout-text-window-reverse"></i><span>Data</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="tables-general.php">
              <i class="bi bi-circle"></i><span>Stok Obat </span> 
            </a>
          </li>
          <li>
            <a href="tables-data.php">
              <i class="bi bi-circle"></i><span>Data Penjualan </span>
            </a>
          </li>
        </ul>
      </li><!-- End Tables Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-bar-chart"></i><span>Charts</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="charts-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="charts-chartjs.html">
              <i class="bi bi-circle"></i><span>Chart.js</span>
            </a>
          </li>
          <li>
            <a href="charts-apexcharts.html">
              <i class="bi bi-circle"></i><span>ApexCharts</span>
            </a>
          </li>
          <li>
            <a href="charts-echarts.html">
              <i class="bi bi-circle"></i><span>ECharts</span>
            </a>
          </li>
        </ul>
      </li><!-- End Charts Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#icons-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-gem"></i><span>Icons</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="icons-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="icons-bootstrap.html">
              <i class="bi bi-circle"></i><span>Bootstrap Icons</span>
            </a>
          </li>
          <li>
            <a href="icons-remix.html">
              <i class="bi bi-circle"></i><span>Remix Icons</span>
            </a>
          </li>
          <li>
            <a href="icons-boxicons.html">
              <i class="bi bi-circle"></i><span>Boxicons</span>
            </a>
          </li>
        </ul>
      </li><!-- End Icons Nav -->

      <li class="nav-heading">Pages</li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="users-profile.html">
          <i class="bi bi-person"></i>
          <span>Profile</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-register.php">
          <i class="bi bi-card-list"></i>
          <span>Register</span>
        </a>
      </li><!-- End Register Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-login.php">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Login</span>
        </a>
      </li><!-- End Login Page Nav -->

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Form Validation</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
          <li class="breadcrumb-item active">Transaksi</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
  <div class="row">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Transaksi Pembelian</h5>
          <p>Lengkapi data transaksi dengan benar.</p>

                    <form class="row g-3" id="form-transaksi" method="POST" action="simpan_transaksi.php">

          <!-- Informasi Obat -->
          <div class="row">
                  <div class="col-md-6">
                      <label for="namaObat" class="form-label">Nama Obat</label>
                      <select class="form-select" id="namaObat" name="id_obat" required>
                          <option selected disabled value="">Pilih Obat...</option>
                          <?php
                          // Query untuk mengambil data obat
                          $query = "SELECT id_obat, nama_obat, harga, golongan, tipe FROM obat";
                          $result = $koneksi->query($query);
                          if ($result->num_rows > 0) {
                              while ($row = $result->fetch_assoc()) {
                                  echo '<option value="' . $row['id_obat'] . '" data-harga="' . $row['harga'] . '" data-golongan="' . $row['golongan'] . '" data-tipe="' . $row['tipe'] . '">' . $row['nama_obat'] . '</option>';
                              }
                          }
                          ?>
                      </select>
                  </div>
                  <div class="col-md-2">
                      <label for="kodeObat" class="form-label">Kode Obat</label>
                      <input type="text" class="form-control" id="kodeObat" readonly style="background-color: #e9ecef;">
                  </div>
                  <div class="col-md-2">
                      <label for="golonganObat" class="form-label">Golongan</label>
                      <input type="text" class="form-control" id="golonganObat" readonly style="background-color: #e9ecef;">
                  </div>
                  <div class="col-md-2">
                      <label for="tipeObat" class="form-label">Tipe</label>
                      <input type="text" class="form-control" id="tipeObat" readonly style="background-color: #e9ecef;">
                  </div>
              </div>

              <!-- Detail Pembelian -->
              <div class="row">
                  <div class="col-md-4">
                      <label for="jumlahPembelian" class="form-label">Jumlah</label>
                      <input type="number" class="form-control" id="jumlahPembelian" name="jumlah_pembelian" min="1" required>
                  </div>
                  <div class="col-md-4">
                      <label for="hargaSatuan" class="form-label">Harga Satuan</label>
                      <div class="input-group">
                          <span class="input-group-text">Rp</span>
                          <input type="text" class="form-control" id="hargaSatuan" readonly style="background-color: #e9ecef;">
                      </div>
                  </div>
                  <div class="col-md-4">
                      <label for="totalHarga" class="form-label">Total Harga</label>
                      <div class="input-group">
                          <span class="input-group-text">Rp</span>
                          <input type="text" class="form-control" id="totalHarga" name="total_harga" readonly style="background-color: #d4edda;">
                      </div>
                  </div>
              </div>

          <!-- Tombol Simpan -->
          <div class="row mt-3">
              <div class="col-12">
                  <button class="btn btn-primary" type="submit">Simpan Transaksi</button>
              </div>
          </div>
          </form>

          <script>
              // Event listener untuk input ID User
              document.getElementById('idUser').addEventListener('input', function() {
                  var idUser = this.value;

                  // Lakukan AJAX request untuk mendapatkan username berdasarkan ID User
                  if (idUser.trim() !== '') {
                      var xhr = new XMLHttpRequest();
                      xhr.open('GET', 'ambil_username.php?id_user=' + encodeURIComponent(idUser), true);
                      xhr.onload = function() {
                          if (xhr.status === 200) {
                              document.getElementById('username').value = xhr.responseText.trim() || 'Tidak ditemukan';
                          } else {
                              document.getElementById('username').value = 'Error';
                          }
                      };
                      xhr.send();
                  } else {
                      document.getElementById('username').value = '';
                  }
              });

              // Event listener untuk nama obat
              document.getElementById('namaObat').addEventListener('change', function() {
                  var selectedOption = this.options[this.selectedIndex];
                  var harga = parseFloat(selectedOption.getAttribute('data-harga'));
                  var idObat = selectedOption.value;
                  var golongan = selectedOption.getAttribute('data-golongan');
                  var tipe = selectedOption.getAttribute('data-tipe');

                  // Autofill untuk kolom terkait obat
                  document.getElementById('hargaSatuan').value = harga.toFixed(2);
                  document.getElementById('kodeObat').value = idObat;
                  document.getElementById('golonganObat').value = golongan;
                  document.getElementById('tipeObat').value = tipe;

                  // Hitung total harga berdasarkan jumlah pembelian
                  var jumlahPembelian = document.getElementById('jumlahPembelian');
                  jumlahPembelian.addEventListener('input', function() {
                      var total = harga * this.value;
                      document.getElementById('totalHarga').value = total.toFixed(2);
                  });
              });
          </script>
                    <!-- End Form Transaksi -->
                  </div>
                </div>
              </div>
            </div>
          </section>


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
  <div class="copyright">
      &copy; Administrasi Basis Data <strong><span>2373020_2373024_2373039</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
<?php
$koneksi->close();
?>