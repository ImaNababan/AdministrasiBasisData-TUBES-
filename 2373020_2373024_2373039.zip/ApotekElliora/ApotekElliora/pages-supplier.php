<?php
include 'koneksi.php';

// Cek jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $id_user = $_POST['id_user'];
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $telepon_pelanggan = $_POST['telepon_pelanggan'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $total_harga = $_POST['total_harga'];
    $id_obat = $_POST['id_obat'];
    $jumlah_pembelian = $_POST['jumlah_pembelian'];
    $harga_satuan = $_POST['hargaSatuan'];

    // Mulai transaksi
    $koneksi->begin_transaction();

    try {
        // 1. Simpan data pelanggan
        $stmt = $koneksi->prepare("INSERT INTO pelanggan (nama, telepon) VALUES (?, ?)");
        $stmt->bind_param("sss", $nama_pelanggan, $telepon_pelanggan);
        $stmt->execute();
        $id_pelanggan = $stmt->insert_id; // Ambil ID pelanggan yang baru aja disimpan
        $stmt->close();

        // 2. Simpan data transaksi (termasuk detail transaksi)
        $stmt = $koneksi->prepare("INSERT INTO transaksi (id_user, id_obat, jumlah, harga, total_harga, tanggal_transaksi, id_pelanggan, pembayaran) VALUES (?, ?, ?, ?, ?, CURDATE(), ?, ?)");
        $stmt->bind_param("iiidiis", $id_user, $id_obat, $jumlah_pembelian, $harga_satuan, $total_harga, $id_pelanggan, $metode_pembayaran);
        $stmt->execute();
        $id_transaksi = $stmt->insert_id; // Ambil ID transaksi yang baru aja disimpan
        $stmt->close();

        // Commit transaksi
        $koneksi->commit();
        echo "<div class='alert alert-success'>Transaksi berhasil disimpan!</div>";
    } catch (Exception $e) {
        // Rollback jika ada kesalahan
        $koneksi->rollback();
        echo "<div class='alert alert-danger'>Transaksi gagal: " . $e->getMessage() . "</div>";
    }
}

// Ambil data transaksi untuk ditampilkan
$query = "SELECT t.id_transaksi, t.tanggal_transaksi, p.nama, t.total_harga 
          FROM transaksi t 
          JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan 
          ORDER BY t.tanggal_transaksi DESC";
$result = $koneksi->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Forms / Validation - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Updated: Apr 20 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="dashboard.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo1.png" alt="">
        <span class="d-none d-lg-block">Apotek Elliora</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->
      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link collapsed" href="dashboard.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="transaksi.php">
          <i class="bi bi-handbag-fill"></i><span>Transaksi</span><i></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          
        </ul>
      </li><!-- End Transaksi -->


      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-layout-text-window-reverse"></i><span>Data</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="tables-general.php">
              <i class="bi bi-circle"></i><span>Stok Obat </span> 
            </a>
          </li>
          <li>
            <a href="tables-data.php">
              <i class="bi bi-circle"></i><span>Data Penjualan </span>
            </a>
          </li>
          <li>
            <a href="supplier.php" class="">
              <i class="bi bi-circle"></i><span>Supplier</span>
            </a>
          </li>
        </ul>
      </li><!-- End Data -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-supplier.php">
          <i class="bi bi-truck"></i><span>Supplier</span><i></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          
        </ul>
      </li><!-- End Supplier -->

    

      <li class="nav-heading">Pages</li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-register.php">
          <i class="bi bi-card-list"></i>
          <span>Register</span>
        </a>
      </li><!-- End Register Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-login.php">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Login</span>
        </a>
      </li><!-- End Login Page Nav -->

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Form Validation</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
          <li class="breadcrumb-item active">Transaksi</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
  <div class="row">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Data Supplier dan Obat</h5>
          <p>Harap cantumkan juga nomor telepon yang bisa dihubungi</p>
           <form class="row g-3" id="form-transaksi" method="POST" action="simpan_data.php">
            <!-- Informasi Supplier -->
            <div class="col-md-6">
                <label for="namaSupplier" class="form-label">Nama Supplier</label>
                <input type="text" class="form-control" id="namaSupplier" name="nama_supplier" required>
            </div>
            <div class="col-md-6">
                <label for="alamatSupplier" class="form-label">Alamat Supplier</label>
                <input type="text" class="form-control" id="alamatSupplier" name="alamat" required>
            </div>
            <div class="col-md-6">
                <label for="teleponSupplier" class="form-label">Telepon Supplier</label>
                <input type="number" class="form-control" id="teleponSupplier" name="nomor_telepon" required>
            </div>
            <div class="col-md-6">
                <label for="emailSupplier" class="form-label">Email Supplier</label>
                <input type="email" class="form-control" id="emailSupplier" name="email" required>
            </div>

            <!-- Informasi Obat -->
            <div class="row">
            <div class="col-md-6">
                <label for="namaObat" class="form-label">Nama Obat</label>
                <input type="text" class="form-control" id="namaObat" name="nama_obat" required>
            </div>  
            <div class="col-md-2">
                <label for="golonganObat" class="form-label">Golongan</label>
                <input type="text" class="form-control" id="golonganObat" name="golongan" required>
            </div>
            <div class="col-md-2">
                <label for="tipeObat" class="form-label">Tipe</label>
                <select class="form-control" id="tipeObat" name="tipe" required>
                    <option value="" disabled selected>Pilih tipe obat</option>
                    <option value="kapsul">Kapsul</option>
                    <option value="sirup">Sirup</option>
                    <option value="tablet">Tablet</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="jumlahObat" class="form-label">Jumlah</label>
                <input type="number" class="form-control" id="jumlahObat" name="jumlah" required>
            </div>
            <div class="col-md-2">
                <label for="hargaObat" class="form-label">Harga</label>
                <input type="text" class="form-control" id="hargaObat" name="harga" required>
            </div>
        </div>

              <!-- Tombol Simpan -->
              <div class="row mt-3">
                  <div class="col-12">
                      <button class="btn btn-primary" type="submit">Simpan Data Supplier</button>
                  </div>
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
  <div class="copyright">
      &copy; Administrasi Basis Data <strong><span>2373020_2373024_2373039</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
<?php
// Tutup koneksi
$koneksi->close();
?>